/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package controlador;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import modelo.app.Mensaje;
import modelo.consultasExternas;
import modelo.entradasExternas;
import modelo.ficherosExternosInterfaz;
import modelo.ficherosLogicosInternos;
import modelo.salidasExternas;

/**
 * FXML Controller class
 *
 * @author Alberto
 */
public class ComplejidadPFController implements Initializable 
{
    @FXML
    private Label totalEE;
    @FXML
    private Label totalSE;
    @FXML
    private Label totalCE;
    @FXML
    private Label totalFLI;
    @FXML
    private Label totalFEI;
    @FXML
    private TextField txtEEB;
    @FXML
    private TextField txtEEM;
    @FXML
    private TextField txtEEA;
    @FXML
    private TextField txtSEB;
    @FXML
    private TextField txtSEM;
    @FXML
    private TextField txtSEA;
    @FXML
    private TextField txtCEB;
    @FXML
    private TextField txtCEM;
    @FXML
    private TextField txtCEA;
    @FXML
    private TextField txtFLIB;
    @FXML
    private TextField txtFLIM;
    @FXML
    private TextField txtFLIA;
    @FXML
    private TextField txtFEIB;
    @FXML
    private TextField txtFEIM;
    @FXML
    private TextField txtFEIA;
    @FXML
    private Label lblEEB;
    @FXML
    private Label lblEEM;
    @FXML
    private Label lblEEA;
    @FXML
    private Label lblSEB;
    @FXML
    private Label lblSEM;
    @FXML
    private Label lblSEA;
    @FXML
    private Label lblCEB;
    @FXML
    private Label lblCEM;
    @FXML
    private Label lblCEA;
    @FXML
    private Label lblFLIB;
    @FXML
    private Label lblFLIM;
    @FXML
    private Label lblFLIA;
    @FXML
    private Label lblFEIB;
    @FXML
    private Label lblFEIM;
    @FXML
    private Label lblFEIA;
    @FXML
    private Label PSsA;
    @FXML
    private Label PFA;
    @FXML
    private TextField VAF;
    @FXML
    private Button btnCalcular;
    entradasExternas EE;
    salidasExternas SE;
    consultasExternas CE;
    ficherosLogicosInternos FLI;
    ficherosExternosInterfaz FEI;
    private Mensaje mensaje;
    @FXML
    private Button btnRegresar;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
    }    

    @FXML
    private void calcularComplejidad(ActionEvent event) 
    {
        EE = new entradasExternas(Integer.parseInt(txtEEB.getText()), Integer.parseInt(txtEEM.getText()), Integer.parseInt(txtEEA.getText()));
        SE = new salidasExternas(Integer.parseInt(txtSEB.getText()), Integer.parseInt(txtSEM.getText()), Integer.parseInt(txtSEA.getText()));
        CE = new consultasExternas(Integer.parseInt(txtCEB.getText()), Integer.parseInt(txtCEM.getText()), Integer.parseInt(txtCEA.getText()));
        FLI = new ficherosLogicosInternos(Integer.parseInt(txtFLIB.getText()), Integer.parseInt(txtFLIM.getText()), Integer.parseInt(txtFLIA.getText()));
        FEI = new ficherosExternosInterfaz(Integer.parseInt(txtFEIB.getText()), Integer.parseInt(txtFEIM.getText()), Integer.parseInt(txtFEIA.getText()));
        lblEEB.setText(Integer.toString(EE.getEiBaja()*3));
        lblEEM.setText(Integer.toString(EE.getEiMedia()*4));
        lblEEA.setText(Integer.toString(EE.getEiAlta()*6));
        lblSEB.setText(Integer.toString(SE.getEoBaja()*4));
        lblSEM.setText(Integer.toString(SE.getEoMedia()*5));
        lblSEA.setText(Integer.toString(SE.getEoAlta()*7));
        lblCEB.setText(Integer.toString(CE.getEqBaja()*3));
        lblCEM.setText(Integer.toString(CE.getEqMedia()*4));
        lblCEA.setText(Integer.toString(CE.getEqAlta()*6));
        lblFLIB.setText(Integer.toString(FLI.getIlfBaja()*7));
        lblFLIM.setText(Integer.toString(FLI.getIlfMedia()*10));
        lblFLIA.setText(Integer.toString(FLI.getIlfAlta()*15));
        lblFEIB.setText(Integer.toString(FEI.getElfBaja()*5));
        lblFEIM.setText(Integer.toString(FEI.getElfMedia()*7));
        lblFEIA.setText(Integer.toString(FEI.getElfAlta()*10));
        totalEE.setText(Integer.toString(EE.totalEE()));
        totalSE.setText(Integer.toString(SE.totalSE()));
        totalCE.setText(Integer.toString(CE.totalCE()));
        totalFLI.setText(Integer.toString(FLI.totalFLI()));
        totalFEI.setText(Integer.toString(FEI.totalFEI()));
        PSsA.setText(Integer.toString(EE.totalEE() + SE.totalSE() + CE.totalCE() + FLI.totalFLI() + FEI.totalFEI()));
        double pntos = EE.totalEE() + SE.totalSE() + CE.totalCE() + FLI.totalFLI() + FEI.totalFEI();
        double vaf = Double.parseDouble(VAF.getText());
        //System.out.println(vaf);
        double pfa = vaf * pntos;
        //System.out.println(pfa);
        PFA.setText(Double.toString(pfa));
    }
    
    @FXML
    public void cerrarVentana()
    {
        try 
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/vista/menuPrincipal.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(loader.load());                                                                         
            MenuPrincipalController controller = loader.getController();
            stage.setScene(scene);
            stage.show();
            Stage myStage = (Stage) this.btnCalcular.getScene().getWindow();
            myStage.close();
        } catch (IOException e) 
        {
            this.mensaje.desplegarMensaje("ERROR", "Error al cargar la vista Principal", e, Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void salir(ActionEvent event) 
    {
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
    }
}
