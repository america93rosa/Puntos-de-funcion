/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package controlador;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import modelo.app.Mensaje;

/**
 * FXML Controller class
 *
 * @author Alberto
 */
public class MenuPrincipalController implements Initializable {

    @FXML
    private Button btnConteoPF;
    @FXML
    private Button btnResumenEstimaciones;
    private final Mensaje mensaje = new Mensaje();
    @FXML
    private Button salir;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
    }    

    @FXML
    private void ingresarConteoPF(ActionEvent event) 
    {
        try 
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/vista/complejidadPF.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(loader.load());                                                                         
            ComplejidadPFController controller = loader.getController();
            stage.setScene(scene);
            stage.show();
            stage.setOnCloseRequest(e -> controller.cerrarVentana());
            Stage myStage = (Stage) this.btnConteoPF.getScene().getWindow();
            myStage.close();
        } catch (IOException e) 
        {
            System.out.println("" + e.getMessage());
            this.mensaje.desplegarMensaje("ERROR", "Error al cargar la vista de Articulos", e, Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void ingresarEstimaciones(ActionEvent event) 
    {
        try 
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/vista/resumenEstimaciones.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(loader.load());                                                                         
            ResumenEstimacionesController controller = loader.getController();
            stage.setScene(scene);
            stage.show();
            stage.setOnCloseRequest(e -> controller.cerrarVentana());
            Stage myStage = (Stage) this.btnConteoPF.getScene().getWindow();
            myStage.close();
        } catch (IOException e) 
        {
            System.out.println("" + e.getMessage());
            this.mensaje.desplegarMensaje("ERROR", "Error al cargar la vista de Articulos", e, Alert.AlertType.ERROR);
        }
    }
    
    public void cerrarVentana()
    {
        try 
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/vista/vistaIntroduccion.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(loader.load());                                                                         
            VistaIntroduccionController controller = loader.getController();
            stage.setScene(scene);
            stage.show();
            Stage myStage = (Stage) this.btnConteoPF.getScene().getWindow();
            myStage.close();
        } catch (IOException e) 
        {
            this.mensaje.desplegarMensaje("ERROR", "Error al cargar la vista Principal", e, Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void salir(ActionEvent event) 
    {
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
    }
    
}
