/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package controlador;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import modelo.app.Mensaje;

/**
 *
 * @author Alberto
 */
public class PM extends Application 
{
    Mensaje mensaje = new Mensaje();
    @Override
    public void start(Stage primaryStage) throws IOException 
    {
        //Cargo la vista
        try 
        {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(controlador.PM.class.getResource("/vista/vistaIntroduccion.fxml"));
            // Cargo la ventana
            Pane ventana = (Pane) loader.load();
            // Cargo el scene
            Scene scene = new Scene(ventana);
            // Seteo la scene y la muestro
            primaryStage.setScene(scene);
            primaryStage.show();
        }catch (IOException e) 
        {
            mensaje.desplegarMensaje("ERROR", "Error al cargar la vista del Introducción", e, Alert.AlertType.ERROR);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
