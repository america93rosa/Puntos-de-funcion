/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package controlador;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import modelo.app.Mensaje;
import modelo.resumenEstimaciones;

/**
 * FXML Controller class
 *
 * @author Alberto
 */
public class ResumenEstimacionesController implements Initializable 
{
    @FXML
    private TextField txtC;
    @FXML
    private TextField txtPF;
    @FXML
    private TextField txtE;
    @FXML
    private Label lblEsfuerzo;
    @FXML
    private TextField txtC1;
    @FXML
    private TextField txtPF1;
    @FXML
    private TextField txtE1;
    @FXML
    private Label lblDuracion;
    @FXML
    private Label lblCantidadPersonas;
    @FXML
    private TextField txtEsfuerzo;
    @FXML
    private TextField txtDuracion;
    @FXML
    private TextField txtDiasMensual;
    @FXML
    private TextField txtHorasDia;
    @FXML
    private TextField txtSueldoMensual;
    @FXML
    private TextField txtDiasMensual2;
    @FXML
    private Label lblCostoDia;
    @FXML
    private TextField txtCostoDia;
    @FXML
    private TextField txtHorasDias2;
    @FXML
    private Label lblCostoHora;
    @FXML
    private TextField txtCostoPromedio;
    @FXML
    private Label lblCosto;
    private final Mensaje mensaje = new Mensaje();
    @FXML
    private Label lblProductividad;
    @FXML
    private Label lblVelocidad;
    @FXML
    private Button btnCalcularEsfuerzo;
    @FXML
    private Button btnCalcularDuracion;
    @FXML
    private Button btnCalcularPersona;
    @FXML
    private Button btnCalcularCostoDia;
    @FXML
    private Button btnCostoHora;
    @FXML
    private Button btnCosto;
    @FXML
    private Button btnProductividad;
    @FXML
    private Button btnVelocidad;
    private resumenEstimaciones resumen = new resumenEstimaciones();
    @FXML
    private TextField txtPF3;
    @FXML
    private TextField txtEsfuerzo2;
    @FXML
    private TextField txtPF4;
    @FXML
    private TextField txtDuracion1;
    @FXML
    private TextField Esfuerzo;
    @FXML
    private Button btncerrarVentana;
    @FXML
    private Button btnSalir;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
    }    
    
    @FXML
    public void cerrarVentana()
    {
        try 
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/vista/menuPrincipal.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(loader.load());                                                                         
            MenuPrincipalController controller = loader.getController();
            stage.setScene(scene);
            stage.show();
            Stage myStage = (Stage) this.btnCalcularEsfuerzo.getScene().getWindow();
            myStage.close();
        } catch (IOException e) 
        {
            this.mensaje.desplegarMensaje("ERROR", "Error al cargar la vista Principal", e, Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void esfuerzo(ActionEvent event) 
    {
        resumen.setC(ParseDouble(txtC.getText()));
        resumen.setPuntosFuncion(ParseDouble(txtPF.getText()));
        resumen.setE(ParseDouble(txtE.getText()));
        this.lblEsfuerzo.setText(Double.toString(resumen.esfuerzo()));
    }

    @FXML
    private void duracion(ActionEvent event) 
    {
        resumen.setC(ParseDouble(txtC1.getText()));
        resumen.setPuntosFuncion(ParseDouble(txtPF1.getText()));
        resumen.setE(ParseDouble(txtE1.getText()));
        this.lblDuracion.setText(Double.toString(resumen.duracion()));
    }

    @FXML
    private void personasPorDia(ActionEvent event) 
    {
        resumen.setEsfuerzo(ParseDouble(this.Esfuerzo.getText()));
        System.out.println(this.Esfuerzo.getText()+" 1");
        resumen.setDuracion(ParseDouble(this.txtDuracion.getText()));
        System.out.println(this.txtDuracion.getText());
        resumen.setCostoDia(ParseDouble(this.txtDiasMensual.getText()));
        System.out.println(this.txtDiasMensual.getText());
        resumen.setCostoHora(ParseDouble(this.txtHorasDia.getText()));
        System.out.println(this.txtHorasDia.getText());
        this.lblCantidadPersonas.setText(Double.toString(resumen.cantidadPersonas()));
    }

    @FXML
    private void costoDia(ActionEvent event) 
    {
        double costoDia = ParseDouble(txtSueldoMensual.getText()) / ParseDouble(txtDiasMensual2.getText());
        this.lblCostoDia.setText(Double.toString(costoDia));
    }

    @FXML
    private void costoHora(ActionEvent event) 
    {
        double costoHora = ParseDouble(txtCostoDia.getText()) / ParseDouble(txtHorasDias2.getText());
        this.lblCostoHora.setText(Double.toString(costoHora));
    }

    @FXML
    private void costo(ActionEvent event) 
    {
        double costo = ParseDouble(txtEsfuerzo.getText()) * ParseDouble(txtCostoPromedio.getText());
        this.lblCosto.setText(Double.toString(costo));
    }

    @FXML
    private void productividad(ActionEvent event) 
    {
        double productividad = ParseDouble(txtEsfuerzo2.getText()) / ParseDouble(txtPF3.getText());
        this.lblProductividad.setText(Double.toString(productividad));
    }

    @FXML
    private void velocidad(ActionEvent event) 
    {
        double velocidad = ParseDouble(txtPF4.getText()) / ParseDouble(txtDuracion1.getText());
        this.lblVelocidad.setText(Double.toString(velocidad));
    }
    
    double ParseDouble(String strNumber) 
    {
        if (strNumber != null && strNumber.length() > 0) 
        {
            try 
            {
               return Double.parseDouble(strNumber);
            } catch(Exception e) 
            {
               return -1;   // or some value to mark this field is wrong. or make a function validates field first ...
            }
        }
        else return 0;
    }

    @FXML
    private void salir(ActionEvent event) 
    {
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
    }
    
}
