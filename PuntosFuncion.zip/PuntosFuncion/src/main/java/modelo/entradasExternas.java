/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Alberto
 */
public class entradasExternas 
{
    int eiBaja;
    int eiMedia;
    int eiAlta;
    int eiTotal;

    public entradasExternas(int eiBaja, int eiMedia, int eiAlta) 
    {
        this.eiBaja = eiBaja;
        this.eiMedia = eiMedia;
        this.eiAlta = eiAlta;
    }

    public int getEiBaja() 
    {
        return eiBaja;
    }

    public void setEiBaja(int eiBaja) 
    {
        this.eiBaja = eiBaja;
    }

    public int getEiMedia() 
    {
        return eiMedia;
    }

    public void setEiMedia(int eiMedia) 
    {
        this.eiMedia = eiMedia;
    }

    public int getEiAlta() 
    {
        return eiAlta;
    }

    public void setEiAlta(int eiAlta) 
    {
        this.eiAlta = eiAlta;
    }

    public int getEiTotal() 
    {
        return eiTotal;
    }

    public void setEiTotal(int eiTotal) 
    {
        this.eiTotal = eiTotal;
    }
    
    public int totalEE()
    {
        eiTotal = (this.eiBaja * 3) + (this.eiMedia * 4) + (this.eiAlta * 6);
        return eiTotal;
    }
}
