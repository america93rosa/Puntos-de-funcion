/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.lang.Math;

/**
 *
 * @author Alberto
 */
public class resumenEstimaciones 
{
    double C;
    double E;
    double puntosFuncion;
    double esfuerzo; // C * PFE
    double duracion; // C * PFE
    double cantidadPersona; // Esfuerzo / (DuracionTotal * 20 * 8)
    double costoDia;
    double costoHora;
    double costo; // Esfuerzo * CosteMedioHora
    double productividad; // Esfuerzo / PF
    double velocidadEntrega; // PF / Duracion

    public double getC() 
    {
        return C;
    }

    public void setC(double C) 
    {
        this.C = C;
    }

    public double getE() 
    {
        return E;
    }

    public void setE(double E) 
    {
        this.E = E;
    }

    public double getPuntosFuncion() 
    {
        return puntosFuncion;
    }

    public void setPuntosFuncion(double puntosFuncion) 
    {
        this.puntosFuncion = puntosFuncion;
    }

    public double getEsfuerzo() 
    {
        return esfuerzo;
    }

    public void setEsfuerzo(double esfuerzo) 
    {
        this.esfuerzo = esfuerzo;
    }

    public double getDuracion() 
    {
        return duracion;
    }

    public void setDuracion(double duracion) 
    {
        this.duracion = duracion;
    }

    public double getCantidadPersona() 
    {
        return cantidadPersona;
    }

    public void setCantidadPersona(double cantidadPersona) 
    {
        this.cantidadPersona = cantidadPersona;
    }

    public double getCostoDia() 
    {
        return costoDia;
    }

    public void setCostoDia(double costoDia) 
    {
        this.costoDia = costoDia;
    }

    public double getCostoHora() 
    {
        return costoHora;
    }

    public void setCostoHora(double costoHora) 
    {
        this.costoHora = costoHora;
    }

    public double getCosto() 
    {
        return costo;
    }

    public void setCosto(double costo) 
    {
        this.costo = costo;
    }

    public double getProductividad() 
    {
        return productividad;
    }

    public void setProductividad(double productividad) 
    {
        this.productividad = productividad;
    }

    public double getVelocidadEntrega() 
    {
        return velocidadEntrega;
    }

    public void setVelocidadEntrega(double velocidadEntrega) 
    {
        this.velocidadEntrega = velocidadEntrega;
    }
    
    public double esfuerzo()
    {
        return this.getC() * Math.pow(this.puntosFuncion, this.getE());
    }
    
    public double duracion()
    {
        double duracion;
        duracion = this.C * Math.pow(this.puntosFuncion, this.E);
        return duracion;
    }
    
    public double cantidadPersonas()
    {
        double cantidadPersonas;
        cantidadPersonas = this.esfuerzo / (this.duracion * this.costoDia * this.costoHora); 
        return cantidadPersonas;
    }
    
    public void costoDia(int sueldo)
    {
        this.costoDia = sueldo / 20;
    }
    
    public void costoHora()
    {
        this.costoHora = this.costoDia / 8;
    }
    
    public double costo()
    {
        return this.esfuerzo * this.costoHora;
    }
    
    public double productividad()
    {
        return this.esfuerzo / this.puntosFuncion;
    }
    
    public double velocidad()
    {
        return this.puntosFuncion / this.duracion();
    }
    
}
