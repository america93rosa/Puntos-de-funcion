/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Alberto
 */
public class salidasExternas 
{
    int eoBaja;
    int eoMedia;
    int eoAlta;
    int eoTotal;

    public salidasExternas(int eoBaja, int eoMedia, int eoAlta) 
    {
        this.eoBaja = eoBaja;
        this.eoMedia = eoMedia;
        this.eoAlta = eoAlta;
    }

    public int getEoBaja() 
    {
        return eoBaja;
    }

    public void setEoBaja(int eoBaja) 
    {
        this.eoBaja = eoBaja;
    }

    public int getEoMedia() 
    {
        return eoMedia;
    }

    public void setEoMedia(int eoMedia) 
    {
        this.eoMedia = eoMedia;
    }

    public int getEoAlta() 
    {
        return eoAlta;
    }

    public void setEoAlta(int eoAlta) 
    {
        this.eoAlta = eoAlta;
    }

    public int getEoTotal() 
    {
        return eoTotal;
    }

    public void setEoTotal(int eoTotal) 
    {
        this.eoTotal = eoTotal;
    }
    
    public int totalSE()
    {
        eoTotal = (this.eoBaja * 4) + (this.eoMedia * 5) + (this.eoAlta * 7);
        return eoTotal;
    }
}
