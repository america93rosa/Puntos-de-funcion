/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Alberto
 */
public class ficherosLogicosInternos 
{
    int ilfBaja;
    int ilfMedia;
    int ilfAlta;
    int ilfTotal;

    public ficherosLogicosInternos(int ilfBaja, int ilfMedia, int ilfAlta) 
    {
        this.ilfBaja = ilfBaja;
        this.ilfMedia = ilfMedia;
        this.ilfAlta = ilfAlta;
    }

    public int getIlfBaja() 
    {
        return ilfBaja;
    }

    public void setIlfBaja(int ilfBaja) 
    {
        this.ilfBaja = ilfBaja;
    }

    public int getIlfMedia() 
    {
        return ilfMedia;
    }

    public void setIlfMedia(int ilfMedia) 
    {
        this.ilfMedia = ilfMedia;
    }

    public int getIlfAlta() 
    {
        return ilfAlta;
    }

    public void setIlfAlta(int ilfAlta) 
    {
        this.ilfAlta = ilfAlta;
    }

    public int getIlfTotal() 
    {
        return ilfTotal;
    }

    public void setIlfTotal(int ilfTotal) 
    {
        this.ilfTotal = ilfTotal;
    }
    
    public int totalFLI()
    {
        ilfTotal = (this.ilfBaja * 7) + (this.ilfMedia * 10) + (this.ilfAlta * 15);
        return ilfTotal;
    }
}
