/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Alberto
 */
public class ficherosExternosInterfaz 
{
    int elfBaja;
    int elfMedia;
    int elfAlta;
    int elftotal;

    public ficherosExternosInterfaz(int elfBaja, int elfMedia, int elfAlta) 
    {
        this.elfBaja = elfBaja;
        this.elfMedia = elfMedia;
        this.elfAlta = elfAlta;
    }

    public int getElfBaja() 
    {
        return elfBaja;
    }

    public void setElfBaja(int elfBaja) 
    {
        this.elfBaja = elfBaja;
    }

    public int getElfMedia() 
    {
        return elfMedia;
    }

    public void setElfMedia(int elfMedia) 
    {
        this.elfMedia = elfMedia;
    }

    public int getElfAlta() 
    {
        return elfAlta;
    }

    public void setElfAlta(int elfAlta) 
    {
        this.elfAlta = elfAlta;
    }

    public int getElftotal() 
    {
        return elftotal;
    }

    public void setElftotal(int elftotal) 
    {
        this.elftotal = elftotal;
    }
    
    public int totalFEI()
    {
        elftotal = (this.elfBaja * 5) + (this.elfMedia * 7) + (this.elfAlta * 10);
        return elftotal;
    }
}
