/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Alberto
 */
public class consultasExternas 
{
    int eqBaja;
    int eqMedia;
    int eqAlta;
    int eqTotal;

    public consultasExternas(int eqBaja, int eqMedia, int eqAlta) 
    {
        this.eqBaja = eqBaja;
        this.eqMedia = eqMedia;
        this.eqAlta = eqAlta;
    }

    public int getEqBaja() 
    {
        return eqBaja;
    }

    public void setEqBaja(int eqBaja) 
    {
        this.eqBaja = eqBaja;
    }

    public int getEqMedia() 
    {
        return eqMedia;
    }

    public void setEqMedia(int eqMedia) 
    {
        this.eqMedia = eqMedia;
    }

    public int getEqAlta() 
    {
        return eqAlta;
    }

    public void setEqAlta(int eqAlta) 
    {
        this.eqAlta = eqAlta;
    }

    public int getEqTotal() 
    {
        return eqTotal;
    }

    public void setEqTotal(int eqTotal) 
    {
        this.eqTotal = eqTotal;
    }
    
    public int totalCE()
    {
        eqTotal = (this.eqBaja * 3) + (this.eqMedia * 4) + (this.eqAlta * 6);
        return eqTotal;
    }
}
